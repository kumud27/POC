import React, { Component } from 'react'
import { withRouter } from 'react-router'
import { graphql } from 'react-apollo'
import gql from 'graphql-tag'

class Header extends Component {
    render() {
        const loggedInUser = this.props.loggedInUserQuery
        console.log(loggedInUser)
        return (
            <div>{loggedInUser.username}</div>
        )
    }
}

const LOGGED_IN_USER_QUERY = gql`
    query LoggedInUserQuery {
        me {
            id
            username
        }
    }
`

export default graphql(LOGGED_IN_USER_QUERY, { 
    name: 'loggedInUserQuery',
}) (withRouter(Header))