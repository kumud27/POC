import React, { Component } from 'react';

class Api extends Component 
 {

    constructor(props)
    {
        super(props);
        this.states = {
            items: [],
            isLoaded: false,
            controls: []
          
          };

          this.state = this.states;
    }
  
    componentDidMount()
    {
            var urlValidUser = "http://localhost:3000/api/users/CheckLoggedUser?MSID=akum151";
            var getControl = "http://localhost:3000/api/masters/GetTeamScreanElements/";
            fetch(urlValidUser)
                    .then(result =>result.json())
                    .then(result => {
                        
                        var teamid = result.responseMessage.recordset[0].TeamID; 
                        console.log(teamid);
                        getControl = getControl + teamid;
                        console.log(getControl);
                        fetch(getControl).then(output =>output.json()).then(output => {
                           //getControl Api calling 
                           this.state.controls = output;

                           // console.log(output);
                        });

                        this.setState({
                            isLoaded: true,
                            items: result
                           
                        })
                        console.log(result);
                    }); 
                 
    }      
    
    
        
        render() 
        {
                
           console.log(this.state);
            var {isLoaded, items, teamid} = this.state; 
           console.log(items);
           
            if(isLoaded)
                {

                    if(items.responseMessage.output.responseMessage != "Valid User" ) 
                    {
                        return <div>{items.responseMessage.output.responseMessage} </div>
                    }
                    else
                    {
                      var user = items.responseMessage.recordset[0]; 
                      teamid = user.teamid  
                      return (<div>
                               <div>Welcome { user.FirstName} {user.LastName} </div>
                               <div>  </div>
                             </div>)

                    }


                   //console.log(items);
                   //console.log(items.responseMessage.output.responseMessage);
                  
                }
                else
                {
                return (
                         <div className = "App">
                             {
                                  <ul>
                                         {this.state.items.map(item => 
                                           <li key ={item.id}>
                                            <a href={item.url}>{item.title}</a>
                                           </li>
                                         )}
                                 </ul>
                            } 
                            </div>
                        );
                }
        }
       // this.state.data.map((item, i) => <li>Test</li>)
    }       
export  default Api;